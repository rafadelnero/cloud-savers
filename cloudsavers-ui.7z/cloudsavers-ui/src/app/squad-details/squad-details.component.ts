import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-squad-details',
  templateUrl: './squad-details.component.html',
  styleUrls: ['./squad-details.component.scss']
})
export class SquadDetailsComponent implements OnInit {
  public squad = {};

  constructor(public dataService: DataService) { }

  ngOnInit() {
    this.dataService.getSquadData().subscribe(data => this.squad = data)
  }
}
