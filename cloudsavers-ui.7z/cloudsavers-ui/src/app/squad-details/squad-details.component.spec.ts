import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SquadDetailsComponent } from './squad-details.component';

describe('SquadDetailsComponent', () => {
  let component: SquadDetailsComponent;
  let fixture: ComponentFixture<SquadDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SquadDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SquadDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
