import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as Chartist from 'chartist';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public dataSquads: Array<any> = []

  constructor(public router: Router, public dataService: DataService) {}

  startAnimationForLineChart(chart){
      let seq: any, delays: any, durations: any;
      seq = 0;
      delays = 80;
      durations = 500;

      chart.on('draw', function(data) {
        if(data.type === 'line' || data.type === 'area') {
          data.element.animate({
            d: {
              begin: 600,
              dur: 700,
              from: data.path.clone().scale(1, 0).translate(0, data.chartRect.height()).stringify(),
              to: data.path.clone().stringify(),
              easing: Chartist.Svg.Easing.easeOutQuint
            }
          });
        } else if (data.type === 'point') {
              seq++;
              data.element.animate({
                opacity: {
                  begin: seq * delays,
                  dur: durations,
                  from: 0,
                  to: 1,
                  easing: 'ease'
                }
              });
          }
      });

      seq = 0;
  };

  ngOnInit() {
    this.dataSquads = [
      {
        name: 'Inferno',
        bigQueryTables: '3',
        bigQueryDataSets: '2',
        bigQuerySize: '2GB',
        dataProcClusters: '0',
        dataProcJobs: '0',
        dataFlowJobs: '0',
        total: '12.000.00'
      },
      {
        name: 'Mercator',
        bigQueryTables: '3',
        bigQueryDataSets: '3',
        bigQuerySize: '4GB',
        dataProcClusters: '0',
        dataProcJobs: '0',
        dataFlowJobs: '0',
        total: '14.350.00'
      },
      {
        name: 'Tintoretto',
        bigQueryTables: '3',
        bigQueryDataSets: '1',
        bigQuerySize: '1.5GB',
        dataProcClusters: '0',
        dataProcJobs: '0',
        dataFlowJobs: '0',
        total: '8.700.00'
      },
      {
        name: 'Magnus',
        bigQueryTables: '4',
        bigQueryDataSets: '3',
        bigQuerySize: '5GB',
        dataProcClusters: '0',
        dataProcJobs: '0',
        dataFlowJobs: '0',
        total: '10.200.00'
      }
    ]

    const costByMonth: any = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August'],
      series: [[5, 12, 18, 24, 29, 35, 42, 45]]
    };

    const optionsCostByMonth: any = {
      lineSmooth: Chartist.Interpolation.cardinal({ tension: 0 }),
      low: 0,
      high: 45,
      chartPadding: { top: 0, right: 0, bottom: 0, left: 0},
    }

    const costByMonthChart = new Chartist.Line('#costByMonthChart', costByMonth, optionsCostByMonth);

    this.startAnimationForLineChart(costByMonthChart);
  }

  gotToSquadDetails(squad: any) {
    this.dataService.setSquadData(squad);
    this.router.navigate(['/squads', squad.name])
  }
}

