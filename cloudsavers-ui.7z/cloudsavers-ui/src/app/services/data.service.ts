import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class DataService {
  public squadDataObservable: BehaviorSubject<any> = new BehaviorSubject<any>({})

  constructor() {}

  public setSquadData(data: any) {
    this.squadDataObservable.next(data)
  }

  public getSquadData() {
    return this.squadDataObservable.asObservable();
  }
}
